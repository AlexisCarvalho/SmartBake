package util;

public class RetornarTroco extends Exception {
}
