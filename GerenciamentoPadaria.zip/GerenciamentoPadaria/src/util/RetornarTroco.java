package util;

import java.io.Serial;

public class RetornarTroco extends Exception {
    @Serial
    private static final long serialVersionUID = 1L;
}
